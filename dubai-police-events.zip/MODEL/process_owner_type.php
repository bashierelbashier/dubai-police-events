<?php

if ($row['OWNER_TYPE']==1)
    $row['OWNER_TYPE']=' فرد ';
else if($row['OWNER_TYPE']==2)
    $row['OWNER_TYPE']=' مؤسسة ';
