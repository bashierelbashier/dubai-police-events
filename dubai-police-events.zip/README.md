Dubai Police Events
is a project for the Dubai police department written in pure PHP
